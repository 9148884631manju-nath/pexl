<?php 
  /* JSON Data */ 
 $filePath="web1/data.xlsx"; 
	$sheetName="Hed";	$data = $r->psGetDatatoJson($filePath,$sheetName); 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XA","XA","Hello myd","","",""],
	["db","XB","XB","This idsf nsd fasdf asdjflasdf","","",""],
 ], 
 "web1/templates/Hed.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>