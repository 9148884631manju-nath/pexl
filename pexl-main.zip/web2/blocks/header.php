<header class="border-b border-gray-100 bg-white sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
      
      <!-- Logo -->
      <?php require_once "web2/themes/logo.php";?>

      <!-- Search Bar (HTMX Enabled) -->
      <div class="flex-1 max-w-xl mx-4">
        <form 
          hx-post="/api/search" 
          hx-target="#search-results" 
          hx-trigger="submit"
          class="relative flex items-center"
        >
          <input 
            type="text" 
            name="q"
            placeholder="Search for products..." 
            class="w-full bg-gray-50 text-sm border border-gray-200 rounded-full py-2.5 pl-4 pr-24 focus:outline-none focus:ring-2 focus:ring-brand-gold/50 focus:border-brand-gold transition"
          />
          <button 
            type="submit" 
            class="absolute right-1.5 bg-black hover:bg-gray-800 text-white text-xs font-semibold px-5 py-1.5 rounded-full transition"
          >
            Search
          </button>
        </form>
      </div>

      <!-- User & Cart Actions -->
      <div class="flex items-center gap-5 text-gray-700">
        <a href="/account" class="hover:text-black transition">
          <i data-lucide="user" class="w-5 h-5"></i>
        </a>
        <a href="/cart" class="hover:text-black transition relative">
          <i data-lucide="shopping-bag" class="w-5 h-5"></i>
        </a>
      </div>
    </div>

    <!-- MAIN NAVIGATION BAR -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center justify-between text-sm">
      
      <!-- All Categories Dropdown Button -->
      <div class="relative">
        <button 
          hx-get="/api/categories-menu" 
          hx-target="#category-dropdown" 
          hx-toggle="class:hidden"
          class="bg-brand-gold hover:bg-brand-gold-hover text-white font-medium px-4 py-2 rounded-md flex items-center gap-2 transition"
        >
          <i data-lucide="menu" class="w-4 h-4"></i>
          All Categories
        </button>
        <div id="category-dropdown" class="hidden absolute top-full left-0 mt-2 w-64 bg-white shadow-xl rounded-lg border border-gray-100 p-2 z-50">
          <!-- Dynamic HTMX content loads here -->
        </div>
      </div>

      <!-- Nav Links -->
      <nav class="hidden md:flex items-center space-x-8 font-medium text-gray-600 text-xs tracking-wide uppercase">
        <?php require_once "web2/themes/mainlinks.php";?>
      </nav>

      <!-- Phone Support -->
      <div class="flex items-center gap-2 text-xs text-gray-500 font-medium">
        <i data-lucide="phone-call" class="w-4 h-4 text-brand-gold"></i>
        <?php require_once "web2/themes/callto.php";?>
      </div>
    </div>
  </header>