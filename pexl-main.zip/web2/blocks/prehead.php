<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>B2B Wholesale Marketplace</title>
  
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- HTMX CDN -->
  <script src="https://unpkg.com/htmx.org@1.9.10"></script>
  
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              gold: '#D9A142',
              'gold-hover': '#C28E34',
              dark: '#082823',
              'dark-muted': '#0D3831',
              light: '#F8F6F0',
            }
          }
        }
      }
    }
  </script>
</head>
<body class="bg-white text-gray-800 font-sans antialiased">