<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>B2B Wholesale Marketplace</title>
  
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- HTMX CDN -->
  <script src="https://unpkg.com/htmx.org@1.9.10"></script>
  
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              gold: '#D9A142',
              'gold-hover': '#C28E34',
              dark: '#082823',
              'dark-muted': '#0D3831',
              light: '#F8F6F0',
            }
          }
        }
      }
    }
  </script>
</head>
<body class="bg-white text-gray-800 font-sans antialiased">

  <!-- TOP UTILITY / LOGO / SEARCH BAR -->
  <header class="border-b border-gray-100 bg-white sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
      
      <!-- Logo -->
      <a href="/" class="flex items-center gap-2 font-bold text-2xl text-gray-900 tracking-tight">
        <span class="p-1.5 bg-brand-gold text-white rounded-lg flex items-center justify-center">
          <i data-lucide="layers" class="w-6 h-6"></i>
        </span>
        B2B
      </a>

      <!-- Search Bar (HTMX Enabled) -->
      <div class="flex-1 max-w-xl mx-4">
        <form 
          hx-post="/api/search" 
          hx-target="#search-results" 
          hx-trigger="submit"
          class="relative flex items-center"
        >
          <input 
            type="text" 
            name="q"
            placeholder="Search for products..." 
            class="w-full bg-gray-50 text-sm border border-gray-200 rounded-full py-2.5 pl-4 pr-24 focus:outline-none focus:ring-2 focus:ring-brand-gold/50 focus:border-brand-gold transition"
          />
          <button 
            type="submit" 
            class="absolute right-1.5 bg-black hover:bg-gray-800 text-white text-xs font-semibold px-5 py-1.5 rounded-full transition"
          >
            Search
          </button>
        </form>
      </div>

      <!-- User & Cart Actions -->
      <div class="flex items-center gap-5 text-gray-700">
        <a href="/account" class="hover:text-black transition">
          <i data-lucide="user" class="w-5 h-5"></i>
        </a>
        <a href="/cart" class="hover:text-black transition relative">
          <i data-lucide="shopping-bag" class="w-5 h-5"></i>
        </a>
      </div>
    </div>

    <!-- MAIN NAVIGATION BAR -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center justify-between text-sm">
      
      <!-- All Categories Dropdown Button -->
      <div class="relative">
        <button 
          hx-get="/api/categories-menu" 
          hx-target="#category-dropdown" 
          hx-toggle="class:hidden"
          class="bg-brand-gold hover:bg-brand-gold-hover text-white font-medium px-4 py-2 rounded-md flex items-center gap-2 transition"
        >
          <i data-lucide="menu" class="w-4 h-4"></i>
          All Categories
        </button>
        <div id="category-dropdown" class="hidden absolute top-full left-0 mt-2 w-64 bg-white shadow-xl rounded-lg border border-gray-100 p-2 z-50">
          <!-- Dynamic HTMX content loads here -->
        </div>
      </div>

      <!-- Nav Links -->
      <nav class="hidden md:flex items-center space-x-8 font-medium text-gray-600 text-xs tracking-wide uppercase">
        <a href="/" class="text-brand-gold font-semibold">Home</a>
        <a href="/shop" class="hover:text-black transition">Shop</a>
        <a href="/electronics" class="hover:text-black transition">Electronics</a>
        <a href="/fashion" class="hover:text-black transition">Fashion & Apparel</a>
        <a href="/contact" class="hover:text-black transition">Contact Us</a>
        <a href="/about" class="hover:text-black transition">About Us</a>
      </nav>

      <!-- Phone Support -->
      <div class="flex items-center gap-2 text-xs text-gray-500 font-medium">
        <i data-lucide="phone-call" class="w-4 h-4 text-brand-gold"></i>
        <span>Call To: <strong class="text-gray-800">+18000000000</strong></span>
      </div>
    </div>
  </header>

  <!-- HERO SECTION -->
  <section class="bg-brand-light py-12 md:py-20 relative overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        <!-- Left Hero Content -->
        <div class="lg:col-span-6 space-y-6">
          <div class="inline-block border border-gray-300 rounded-full px-4 py-1.5 text-xs text-gray-600 font-medium tracking-wide">
            B2B COMMERCE • BULK BUYING • GLOBAL TRADE
          </div>

          <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight tracking-tight">
            Quality Products.<br />
            <span class="text-brand-gold">Smarter Sourcing.</span>
          </h1>

          <p class="text-gray-500 text-sm sm:text-base max-w-lg leading-relaxed">
            Connect with trusted manufacturers and discover premium wholesale products at competitive prices. Enjoy flexible MOQs, reliable suppliers, and fast global shipping.
          </p>

          <div class="flex flex-wrap gap-4 pt-2">
            <button 
              hx-get="/api/request-quote-modal" 
              hx-target="#modal-container"
              class="bg-brand-gold hover:bg-brand-gold-hover text-white font-semibold px-6 py-3 rounded-md text-sm transition shadow-sm"
            >
              Request a Quote
            </button>

            <a 
              href="/products" 
              class="bg-brand-dark hover:bg-brand-dark-muted text-white font-semibold px-6 py-3 rounded-md text-sm transition shadow-sm"
            >
              Explore Products
            </a>
          </div>
        </div>

        <!-- Right Hero Visual Product Display -->
        <div class="lg:col-span-6 relative flex justify-center items-end min-h-[320px]">
          <div class="grid grid-cols-3 gap-3 items-end w-full max-w-md">
            
            <!-- Left Item (Headphones & Chair) -->
            <div class="flex flex-col items-center gap-3">
              <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=300&q=80" alt="Headphones" class="w-20 h-20 object-cover rounded-full shadow-md">
              <div class="w-full h-32 bg-stone-200/60 rounded-t-2xl overflow-hidden p-2">
                <img src="https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=300&q=80" alt="Chair" class="w-full h-full object-cover rounded-t-xl">
              </div>
            </div>

            <!-- Center Pedestal Item (Cookware / Plant) -->
            <div class="flex flex-col items-center gap-3">
              <img src="https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=300&q=80" alt="Plant" class="w-24 h-24 object-cover rounded-full shadow-md">
              <div class="w-full h-44 bg-stone-200/80 rounded-t-2xl overflow-hidden p-2">
                <img src="https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=300&q=80" alt="Pot" class="w-full h-full object-cover rounded-t-xl">
              </div>
            </div>

            <!-- Right Items (Bag & Drill) -->
            <div class="flex flex-col items-center gap-3">
              <img src="https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=300&q=80" alt="Handbag" class="w-20 h-20 object-cover rounded-xl shadow-md">
              <div class="w-full h-28 bg-stone-200/60 rounded-t-2xl overflow-hidden p-2">
                <img src="https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=300&q=80" alt="Drill" class="w-full h-full object-cover rounded-t-xl">
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- LOGO BANNER -->
  <section class="py-8 border-b border-gray-100 bg-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <h2 class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">
        Trusted by Leading Businesses Worldwide
      </h2>
      <div class="flex flex-wrap items-center justify-center gap-8 md:gap-12 opacity-75 grayscale hover:grayscale-0 transition-all">
        <span class="font-bold text-lg text-gray-700">Alibaba.com</span>
        <span class="font-bold text-lg text-gray-800">COSTCO</span>
        <span class="font-bold text-lg text-blue-600">ebay</span>
        <span class="font-bold text-lg text-gray-600">global sources</span>
        <span class="font-bold text-lg tracking-widest text-black">BOSE</span>
        <span class="font-semibold text-lg text-gray-900">dyson</span>
        <span class="font-bold text-lg text-blue-800">SAMSUNG</span>
      </div>
    </div>
  </section>

  <!-- SHOP BY CATEGORY (WITH REAL IMAGES) -->
  <section class="py-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h2 class="text-xl font-bold text-gray-900 mb-6">Shop By Category</h2>

    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
      
      <!-- Electronics -->
      <a href="/category/electronics" class="group bg-rose-50/50 rounded-xl p-3 flex flex-col items-center text-center hover:shadow-md transition">
        <div class="w-full h-28 mb-3 overflow-hidden rounded-lg">
          <img src="https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=300&q=80" alt="Electronics" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
        </div>
        <span class="text-xs font-semibold bg-white px-3 py-1.5 rounded-md shadow-sm text-gray-800 w-full">
          Electronics
        </span>
      </a>

      <!-- Home & Kitchen -->
      <a href="/category/home-kitchen" class="group bg-orange-50/50 rounded-xl p-3 flex flex-col items-center text-center hover:shadow-md transition">
        <div class="w-full h-28 mb-3 overflow-hidden rounded-lg">
          <img src="https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=300&q=80" alt="Home & Kitchen" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
        </div>
        <span class="text-xs font-semibold bg-white px-3 py-1.5 rounded-md shadow-sm text-gray-800 w-full">
          Home & Kitchen
        </span>
      </a>

      <!-- Fashion -->
      <a href="/category/fashion" class="group bg-amber-50/50 rounded-xl p-3 flex flex-col items-center text-center hover:shadow-md transition">
        <div class="w-full h-28 mb-3 overflow-hidden rounded-lg">
          <img src="https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=300&q=80" alt="Fashion" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
        </div>
        <span class="text-xs font-semibold bg-white px-3 py-1.5 rounded-md shadow-sm text-gray-800 w-full">
          Fashion
        </span>
      </a>

      <!-- Skin Care -->
      <a href="/category/skincare" class="group bg-red-50/50 rounded-xl p-3 flex flex-col items-center text-center hover:shadow-md transition">
        <div class="w-full h-28 mb-3 overflow-hidden rounded-lg">
          <img src="https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=300&q=80" alt="Skin Care" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
        </div>
        <span class="text-xs font-semibold bg-white px-3 py-1.5 rounded-md shadow-sm text-gray-800 w-full">
          Skin Care
        </span>
      </a>

      <!-- Industrial -->
      <a href="/category/industrial" class="group bg-rose-50/50 rounded-xl p-3 flex flex-col items-center text-center hover:shadow-md transition">
        <div class="w-full h-28 mb-3 overflow-hidden rounded-lg">
          <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=300&q=80" alt="Industrial" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
        </div>
        <span class="text-xs font-semibold bg-white px-3 py-1.5 rounded-md shadow-sm text-gray-800 w-full">
          Industrial
        </span>
      </a>

      <!-- Office Products -->
      <a href="/category/office-products" class="group bg-amber-50/50 rounded-xl p-3 flex flex-col items-center text-center hover:shadow-md transition">
        <div class="w-full h-28 mb-3 overflow-hidden rounded-lg">
          <img src="https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=300&q=80" alt="Office Products" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
        </div>
        <span class="text-xs font-semibold bg-white px-3 py-1.5 rounded-md shadow-sm text-gray-800 w-full">
          Office Products
        </span>
      </a>

    </div>
  </section>

  <!-- BANNER: WHOLESALE PRICING MADE SIMPLE -->
  <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
    <div class="bg-brand-dark rounded-2xl p-6 lg:p-8 text-white flex flex-col lg:flex-row items-center justify-between gap-6 relative overflow-hidden">
      
      <!-- Left Info -->
      <div class="space-y-1.5 max-w-md">
        <h3 class="text-xl font-bold">Wholesale Pricing Made Simple</h3>
        <p class="text-xs text-emerald-100/70 leading-relaxed">
          Unlock better pricing, simplified sourcing, and product solutions.
        </p>
      </div>

      <!-- Center Feature Badges -->
      <div class="flex flex-wrap items-center gap-3 text-xs">
        <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 rounded-lg px-3.5 py-2">
          <i data-lucide="percent" class="w-4 h-4 text-brand-gold"></i>
          <div>
            <div class="font-semibold text-white">Bulk Savings</div>
            <div class="text-[10px] text-gray-300">Tiered Prices</div>
          </div>
        </div>

        <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 rounded-lg px-3.5 py-2">
          <i data-lucide="shield-check" class="w-4 h-4 text-brand-gold"></i>
          <div>
            <div class="font-semibold text-white">Flexible MOQs</div>
            <div class="text-[10px] text-gray-300">Order Your Way</div>
          </div>
        </div>

        <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/10 rounded-lg px-3.5 py-2">
          <i data-lucide="box" class="w-4 h-4 text-brand-gold"></i>
          <div>
            <div class="font-semibold text-white">Private Label</div>
            <div class="text-[10px] text-gray-300">Custom Solutions</div>
          </div>
        </div>
      </div>

      <!-- Right Visual & Button -->
      <div class="flex items-center gap-4">
        <img src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=150&q=80" alt="Shipping Box" class="w-14 h-14 object-cover rounded-lg border border-white/20">
        <button 
          hx-get="/api/start-sourcing" 
          hx-target="#modal-container"
          class="bg-brand-gold hover:bg-brand-gold-hover text-white text-xs font-semibold px-5 py-3 rounded-md transition whitespace-nowrap"
        >
          Start Sourcing
        </button>
      </div>

    </div>
  </section>

  <!-- FEATURED WHOLESALE PRODUCTS (WITH SAMPLE PRODUCTS) -->
  <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
    <h2 class="text-xl font-bold text-gray-900 mb-6">Featured Wholesale Products</h2>

    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
      
      <!-- Product 1 -->
      <div class="bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-md transition flex flex-col">
        <img src="https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=300&q=80" alt="Smart Watch" class="w-full h-32 object-cover rounded-lg mb-2">
        <h4 class="text-xs font-semibold text-gray-800 line-clamp-1">Smart Fitness Watch</h4>
        <p class="text-[11px] text-brand-gold font-bold mt-1">$12.50 / unit</p>
        <span class="text-[10px] text-gray-400 mt-auto pt-2">MOQ: 50 pcs</span>
      </div>

      <!-- Product 2 -->
      <div class="bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-md transition flex flex-col">
        <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=300&q=80" alt="Headphones" class="w-full h-32 object-cover rounded-lg mb-2">
        <h4 class="text-xs font-semibold text-gray-800 line-clamp-1">Wireless ANC Headphones</h4>
        <p class="text-[11px] text-brand-gold font-bold mt-1">$28.00 / unit</p>
        <span class="text-[10px] text-gray-400 mt-auto pt-2">MOQ: 20 pcs</span>
      </div>

      <!-- Product 3 -->
      <div class="bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-md transition flex flex-col">
        <img src="https://images.unsplash.com/photo-1608248597261-5421d55ab367?auto=format&fit=crop&w=300&q=80" alt="Skin Serum" class="w-full h-32 object-cover rounded-lg mb-2">
        <h4 class="text-xs font-semibold text-gray-800 line-clamp-1">Organic Face Serum</h4>
        <p class="text-[11px] text-brand-gold font-bold mt-1">$4.20 / unit</p>
        <span class="text-[10px] text-gray-400 mt-auto pt-2">MOQ: 100 pcs</span>
      </div>

      <!-- Product 4 -->
      <div class="bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-md transition flex flex-col">
        <img src="https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=300&q=80" alt="Cookware Set" class="w-full h-32 object-cover rounded-lg mb-2">
        <h4 class="text-xs font-semibold text-gray-800 line-clamp-1">Ceramic Cooking Pot</h4>
        <p class="text-[11px] text-brand-gold font-bold mt-1">$18.90 / unit</p>
        <span class="text-[10px] text-gray-400 mt-auto pt-2">MOQ: 10 pcs</span>
      </div>

      <!-- Product 5 -->
      <div class="bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-md transition flex flex-col">
        <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=300&q=80" alt="Sneakers" class="w-full h-32 object-cover rounded-lg mb-2">
        <h4 class="text-xs font-semibold text-gray-800 line-clamp-1">Athletic Running Shoes</h4>
        <p class="text-[11px] text-brand-gold font-bold mt-1">$15.00 / unit</p>
        <span class="text-[10px] text-gray-400 mt-auto pt-2">MOQ: 30 pairs</span>
      </div>

      <!-- Product 6 -->
      <div class="bg-white border border-gray-100 rounded-xl p-3 shadow-sm hover:shadow-md transition flex flex-col">
        <img src="https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=300&q=80" alt="Drill" class="w-full h-32 object-cover rounded-lg mb-2">
        <h4 class="text-xs font-semibold text-gray-800 line-clamp-1">Cordless Power Drill</h4>
        <p class="text-[11px] text-brand-gold font-bold mt-1">$35.00 / unit</p>
        <span class="text-[10px] text-gray-400 mt-auto pt-2">MOQ: 15 pcs</span>
      </div>

    </div>
  </section>

  <!-- Dynamic Modal Container for HTMX Requests -->
  <div id="modal-container"></div>

  
</body>
</html>