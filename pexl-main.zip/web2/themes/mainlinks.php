<?php 
  /* JSON Data */ 
 $filePath="web2/data.xlsx"; 
	$sheetName="mainlinks";	$data = $r->psGetDatatoJson($filePath,$sheetName); 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XA","XA","Home","","",""],
	["db","XLINK","XLINK","#","","",""],
 ], 
 "web2/templates/mainlinks.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>