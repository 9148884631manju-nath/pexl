<?php 
  /* JSON Data */ 
 $filePath="web2/data.xlsx"; 
	$sheetName="callto";	$data = $r->psGetDatatoJson($filePath,$sheetName); 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XA","XA","Call To:","","",""],
	["db","XB","XB","+18000000000","","",""],
 ], 
 "web2/templates/callto.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>