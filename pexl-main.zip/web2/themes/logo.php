<?php 
  /* JSON Data */ 
 $filePath="web2/data.xlsx"; 
	$sheetName="logo";	$data = $r->psGetDatatoJson($filePath,$sheetName); 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XA","XA","BAE","","",""],
 ], 
 "web2/templates/logo.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>