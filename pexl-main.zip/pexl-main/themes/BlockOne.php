<?php 
  /* JSON Data */ 
 $filePath="data/data.xlsx"; 
	$sheetName="BlockOne";	$data = $r->psGetDatatoJson($filePath,$sheetName); 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XTITLE_","XTITLE_","My Head","","",""],
	["db","XPARA_","XPARA_","My Para this","","",""],
 ], 
 "templates/BlockOne.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>