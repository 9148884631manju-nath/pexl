<?php 
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;

$r = new ExcelReader();



$theme = (isset($_REQUEST['theme'])) ? $_REQUEST['theme'] : "";
if(file_exists($theme)){
 require_once "inc/glob.php";
require_once $theme; 
}else{
 
}

$proj = (isset($_REQUEST['proj'])) ? $_REQUEST['proj'] : "";
if($proj==""){}else{
 include_once $proj."/blocks/prehead.php";

 include_once $proj."/blocks/header.php";

 require_once "web2/themes/herosection.php"; 

 include_once $proj."/blocks/suffooter.php";
}
?>