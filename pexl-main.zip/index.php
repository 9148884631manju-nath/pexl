<?php 
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;

$r = new ExcelReader();

$filePath="web3/data/webcon.xlsx"; 
$sheetName="global";	
$data = $r->psGetDatatoJson($filePath,$sheetName); 
//var_dump($data);
$res="";

for($i=0;$i<count($data);$i+=1){ 
 switch($data[$i]->type){
  case "title":
    $res.='<title>'.$data[$i]->tvalue.'</title>'."\n";
   break;
  case "script":
   $res.='<script '.$data[$i]->tattr.'="'.$data[$i]->tvalue.'" ></script>'."\n";
   break;
   case "link":
   $res.='<link '.$data[$i]->tattr.'="'.$data[$i]->tvalue.'" '.$data[$i]->sattr.'="'.$data[$i]->svalue.'" '.$data[$i]->uattr.' />'."\n";
   break;
  default:
  break;
 }
}
$cde="\n".'<?php'."\n".'require_once "pre-header.php";'."\n".'echo "Welcome";'."\n".'require_once "suf-footer.php";'."\n".'?>'."\n";
$fda = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> '.$res.' </head><body>';
file_put_contents("web3/blocks/pre-header.php",$fda);
file_put_contents("web3/blocks/suf-footer.php",'</body></html>');

$theme = (isset($_REQUEST['theme'])) ? $_REQUEST['theme'] : "";
if(file_exists($theme)){
 require_once "inc/glob.php";
require_once $theme; 
}else{
 
}

$proj = (isset($_REQUEST['proj'])) ? $_REQUEST['proj'] : "";
if($proj==""){}else{
 include_once $proj."/blocks/prehead.php";

 include_once $proj."/blocks/header.php";

 require_once "web2/themes/herosection.php"; 

 include_once $proj."/blocks/suffooter.php";
}
?>