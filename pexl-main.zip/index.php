<?php 
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$file="data/data.xlsx";
$sheet="Sheet1";
$r = new ExcelReader();
$setProj = $r->setProj("web1");

require_once "inc/glob.php";

$theme = (isset($_REQUEST['theme'])) ? $_REQUEST['theme'] : "";
if(file_exists($theme)){
require_once $theme; 
}else{
 
}

?>