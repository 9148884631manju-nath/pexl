<?php 
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();

$proj = (isset($_REQUEST['proj'])) ? $_REQUEST['proj'] : "gfg";
$code = (isset($_REQUEST['code'])) ? $_REQUEST['code'] : "";
$prjcon = (isset($_REQUEST['prjcon'])) ? $_REQUEST['prjcon'] : "";
$theme = (isset($_REQUEST['theme'])) ? $_REQUEST['theme'] : "";
$projx="projects/".$proj; 
$pr="";

if(file_exists($theme)){ 
  if($code=="raw")
  {

  }
  else
  {
  require_once "inc/glob.php";
  }
  require_once $theme; 
}

if($prjcon=="yes")
{
  $proj="";
}

if($code=="raw")
{
  include_once $projx."/blocks/content.php";
}
else
{
  if($proj==""){
    $pr="111";
  }
  else
  {
    
    if(file_exists($projx."/blocks/pre-header.php"))
    {
      include_once $projx."/blocks/pre-header.php";
    }
    else
    {
      $pr.="1";
    }
    if(file_exists($projx."/blocks/content.php"))
    {
      include_once $projx."/blocks/content.php";
    }
    else
    {
      $pr.="1";
    }
    if(file_exists($projx."/blocks/suf-footer.php"))
    {
      include_once $projx."/blocks/suf-footer.php";
    }
    else
    {
      $pr.="1";
    }
  }
}
if($pr=="111" or $prjcon=="yes")
{
  require_once "inc/glob.php"; $fx="cp";
  require_once "createproject.php";
}
?>