<?php 
$frmfldvv=isset($_REQUEST["frmfld"]) ? $_REQUEST["frmfld"] : "" ;
$flo=isset($_REQUEST["flo"]) ? $_REQUEST["flo"] : "";
if(isset($_REQUEST["page"]) or file_exists($_REQUEST["page"].".php")){
require_once $_REQUEST["page"].".php";}else{}
?>