<?php
$frmfld = file_get_contents("formset/formmodes.json");
$frmfldx = json_decode($frmfld);
$frmfldvv = ($frmfldvv=="") ? "text" : $frmfldvv;
$fmx = $frmfldx->$frmfldvv;
foreach($fmx as $kk=>$vv){
 ?>
 <div class="p-1 w-full"><?= $vv ?><input name="<?= $flo.$kk ?>" type="text" value="<?= $flo ?>" placeholder="<?= $vv ?>" class="w-full border border-amber-700/60 rounded-none px-3 py-2 text-stone-800 placeholder-amber-700/50 focus:outline-none focus:ring-1 focus:ring-amber-800" /></div>
 <?php
}
?>