<div class="flex min-h-screen items-center justify-center bg-[#f3f3f3] p-6 font-sans">
  <div class="max-w-xl text-left">
    <!-- Main Heading -->
    <h1 class="text-3xl font-bold tracking-tight text-[#111111] sm:text-4xl">
      Greetings from PEXL.
    </h1>
    
    <!-- Subtext -->
    <p class="mt-3 text-base leading-relaxed text-[#555555]">
     Update your Main Page and create Pages in pages folder <br/>Projects \ Your Project Folder \ pages \ main.php
    </p>
    
    <!-- Call to Action Buttons -->
    <div class="mt-6 flex flex-wrap gap-3">
      <!-- Dark Button -->
      <button onclick="window.location='?proj=<?= $proj?>&admin=yes'" class="bg-[#0b1325] px-6 py-3 text-xs font-bold uppercase tracking-wider text-white transition hover:bg-opacity-90">
       Proceed
      </button>
      
    </div>
  </div>
</div>