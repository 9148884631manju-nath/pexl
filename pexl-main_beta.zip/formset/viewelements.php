<?php
$sd = $r->sdir($projx."themes");
if(count($sd)>0){
 $html=$r->htmlint( 
 $sd, 
 [
     ["db","filename","filename","Project","","",""],
     ["db","filename","basename","Link","","?proj=".$proj."&ele=",""],
     ["txt","TGT","TGT","_blank","","",""],
 ], 
 "templates/procard.html" 
 );
 ?>
 
<?php
 echo $html;
 ?><?php
}
?>