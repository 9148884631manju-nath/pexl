<div class="flex min-h-screen items-center justify-center bg-[#f3f3f3] p-6 font-sans">
  <div class="max-w-xl text-center">
    <!-- Main Heading -->
    <h1 class="text-3xl font-bold tracking-tight text-[#111111] sm:text-4xl">
      <?=  strtoupper($proj) ?> - APP <br/><br/>404 Error.
    </h1>
    
    <!-- Subtext -->
    <p class="mt-3 text-base leading-relaxed text-[#555555]">
     <?= $page ?> - Page Under Construction.
    </p>
    
    
  </div>
</div>