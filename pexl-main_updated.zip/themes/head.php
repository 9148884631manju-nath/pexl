<?php 
  /* JSON Data */ 
 $filePath="data/data.xlsx"; 
	$sheetName="head";	$data = $r->psGetDatatoJson($filePath,$sheetName); 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XA","XA","Title","","",""],
	["db","XB","XB","My Para","","",""],
 ], 
 "templates/head.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>