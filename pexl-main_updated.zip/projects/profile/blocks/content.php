<?php 
$proj=isset($_REQUEST["proj"]) ? $_REQUEST["proj"] : "web";
$projx="projects/".$proj."/";
$page=isset($_REQUEST["page"]) ? $_REQUEST["page"] : "";
$webset = (isset($_REQUEST["webset"])) ? $_REQUEST["webset"] : "";
$pageCall = $projx."blocks/".$page.".php";
$webSetCall = $projx."webset/".$webset.".php";
if($webset==""){
if($page==""){
echo '<div class="max-w-7xl mx-auto px-6 pt-16 pb-12 lg:pt-24 lg:pb-20"><h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight text-gold text-center"><img src="pexl-logo.png" width="200" /></h1><br/><br/><p class=" sm:text-lg leading-relaxed p-5 text-dark">PEXL is an ultra-lightweight, signal-driven web app framework designed for high-performance frontend micro-apps. Native Twind integration gives you instant dynamic styling without context setup.</p><button type="button" onclick="window.location=\'render.php?proj='.$proj.'\'" class="px-4 py-2 bg-gold hover:bg-gold-hover text-dark text-xs font-bold rounded-xl shadow-sm transition-colors">Create Elements</button></div>';
}else{
 if(file_exists($pageCall)){
require_once $pageCall;
}else{
echo "Invalid Page";
}
}
}else{
 require_once $webSetCall;
}
?>