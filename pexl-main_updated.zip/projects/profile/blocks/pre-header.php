<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php 
$filepath="projects/profile/data/webcon.xlsx";
echo $r->crpre($filepath);
 
 ?> </head><body>