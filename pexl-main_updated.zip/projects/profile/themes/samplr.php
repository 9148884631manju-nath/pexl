<?php 
  /* JSON Data */ 
 $filePath="projects/profile//data/data.xlsx"; 
	$sheetName="samplr"; 
	$data = $r->psGetDatatoJson($filePath,$sheetName); 
 $from=isset($_REQUEST['recordfrom']) ? $_REQUEST['recordfrom'] : 0; 
	$to=isset($_REQUEST['recordto']) ? $_REQUEST['recordto'] : count($data); 
 $ndata= array();
	for($i=$from;$i<$to;$i+=1)		{	$ndata[$i]=$data[$i]; } 

 /* JSON Data to HTML Template */ 
 $html=$r->htmlint( 
 $data, 
 [
	["db","XA","XA","hee","","",""],
 ], 
 "projects/profile/templates/samplr.html" 
 ); 

 /* Print HTML Data */ 
 echo $html; 
 ?>