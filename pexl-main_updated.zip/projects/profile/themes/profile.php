<?php 
  /* JSON Data */ 
 $filePath="projects/profile//data/data.xlsx";
	$sheetName="profile";	$data = $r->psGetDatatoJson($filePath,$sheetName);
	$recordid=isset($_REQUEST['recordid']) ? $_REQUEST['recordid'] : "nil";
	$view=isset($_REQUEST['view']) ? $_REQUEST['view'] : "";
	switch($view)
	{
		case "recordedit":
			if(array_key_exists($recordid,$data)){
			$data = $data[$recordid];
			var_dump($data);
			}else{
				echo "No Data";
			}
		break;
		default:
			$from=isset($_REQUEST['recordfrom']) ? $_REQUEST['recordfrom'] : 0;
			$to=isset($_REQUEST['recordto']) ? $_REQUEST['recordto'] : count($data);
			$ndata= array();
			for($i=$from;$i<$to;$i+=1)
				{
						$ndata[$i]=$data[$i];
				}
			/* JSON Data to HTML Template */ 
			$html=$r->htmlint( 
			$ndata, 
			[
			["db","XA","XA","Manjunath","","",""],
			["db","XB","XB","Principal Architect","","",""],
			["db","XC","XC","Edit Profile","","",""],
			["db","XD","XD","About","","",""],
			["db","XE","XE","Specializing in modern minimalist architecture and spatial UI design. Dedicated to luxury aesthetics and sustainable planning.","","",""],
			["db","XF","XF","Email","","",""],
			["db","XG","XG","elena.rostova@example.com","","",""],
			["db","XH","XH","Location","","",""],
			["db","XI","XI","Zurich, Switzerland","","",""],
			["db","XJ","XJ","24","","",""],
			["db","XK","XK","Projects","","",""],
			["db","XL","XL","12","","",""],
			["db","XM","XM","Awards","","",""],
			["db","XN","XN","98%","","",""],
			["db","XO","XO","Success Rate","","",""],
			], 
			"projects/profile/templates/profile.html" 
			); 

			/* Print HTML Data */ 
			echo $html;
		break;
	}
	 
 ?>