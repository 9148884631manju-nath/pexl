<?php
$fx = isset($_REQUEST['fx']) ? $_REQUEST['fx'] : $fx ;
switch($fx)
{
    case "code":
                $proj=$_POST["pname"];
                require_once "install.php";
        break;
    case "cp":
        ?>
        
        <form 
id="create-project-form"
hx-post="createproject.php?fx=code" 
hx-target="#form-container" 
hx-swap="innerHTML transition:true"
hx-indicator="#submit-loader"
class="p-6 sm:p-10 space-y-8"
> 
<div>
               <h1 class="font-serif sm:text-2xl font-bold text-dark mt-2 tracking-tight"><img src="pexl-logo.png" width="100" /> Create New Project</h1>
                <p class="text-xs sm:text-sm text-dark-muted mt-1 font-light">Set up details, assets, collaborators, and visibility for your new venture.</p>
            </div>
        <div id="form-container"></div>
<div class="flex gap-2">
<input 
    type="text" 
    id="collaborator-input" 
    name="pname";
    placeholder="Type member name or email..." 
    class="flex-1 px-3 py-1.5 bg-light-surface border border-brand-700 rounded-lg text-xs text-dark placeholder-brand-muted/700 focus:outline-none focus:border-gold"
>
<button 
    type="submit" 
    id="submit-btn" 
    class="w-full sm:w-auto px-8 py-3 rounded-xl border border-brand-700 text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-lg items-center justify-center gap-2"
>
    <!-- HTMX Loading Spinner -->
    <span id="submit-loader" class="htmx-indicator items-center gap-2">
        <i class="fa-solid fa-circle-notch fa-spin text-gold"></i>
    </span>
    <span>Create Project</span>
</button>
</div>
 <h1 class="font-serif text-3xl sm:text-2xl font-bold text-dark mt-2 tracking-tight">Projects</h1><br/>
<?php
     $sd = $r->sdir("projects"); 
        $html=$r->htmlint( 
        $sd, 
        [
            ["db","filename","filename","Project","","",""],
            ["db","basename","basename","Link","","",""],
        ], 
        "templates/procard.html" 
        );
        echo $html;   
?>

</form>
        <?php

        
       
        break;
    default:
    break;
}

?>
