<main class="w-full max-w-xl relative z-10 my-auto">
        
        <!-- Luxury Card Outer Container -->
        <div class="bg-card-bg border border-border-light rounded-3xl p-8 sm:p-12 shadow-xl shadow-dark/5 relative overflow-hidden text-center">
            
            <!-- Top Gold Decorative Accent Bar -->
            <div class="absolute top-0 left-1/2 -translate-x-1/2 w-2/3 h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent"></div>

            <!-- Header / Brand Emblem -->
            <div class="inline-flex items-center justify-center w-12 h-12 rounded-full border border-gold/30 bg-light/50 mb-6 shadow-inner">
                <i class="fa-solid fa-compass text-gold text-lg"></i>
            </div>

            <!-- 404 Display with Gold Geometric Frame Effect -->
            <div class="relative mb-6">
                <span class="font-serif text-8xl sm:text-9xl font-light tracking-wider text-dark select-none block drop-shadow-sm">
                    4<span class="text-gold italic font-normal">0</span>4
                </span>
                <p class="text-xs uppercase tracking-[0.3em] text-gold font-semibold mt-1">
                    Sanctuary Not Found
                </p>
            </div>

            <!-- Message Subtitle -->
            <p class="text-dark-muted font-sans text-sm sm:text-base leading-relaxed max-w-md mx-auto mb-8 font-normal">
                The sanctuary or page you are seeking does not exist, has been relocated, or is temporarily restricted.
            </p>

            <!-- Search Bar -->
            <form onsubmit="handleSearch(event)" class="relative max-w-md mx-auto mb-8">
                <div class="relative flex items-center">
                    <input 
                        type="text" 
                        id="searchInput" 
                        placeholder="Search our directory or collection..." 
                        class="w-full pl-11 pr-24 py-3.5 bg-light border border-border-light rounded-xl text-dark text-sm placeholder-dark-muted/50 focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold transition-all duration-300 shadow-inner"
                    >
                    <i class="fa-solid fa-magnifying-glass absolute left-4 text-dark-muted/50 text-sm"></i>
                    <button 
                        type="submit" 
                        class="absolute right-1.5 px-4 py-2 bg-dark hover:bg-dark-muted text-light text-xs font-medium uppercase tracking-wider rounded-lg transition-colors duration-200"
                    >
                        Search
                    </button>
                </div>
            </form>

            <!-- Action Buttons -->
            <div class="flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-md mx-auto">
                <!-- Back to Home Button -->
                <a 
                    href="#" 
                    class="w-full sm:w-1/2 py-3.5 px-5 rounded-xl bg-gold hover:bg-gold-hover text-white font-semibold text-xs tracking-widest uppercase transition-all duration-300 shadow-md shadow-gold/20 flex items-center justify-center gap-2 group active:scale-[0.99]"
                >
                    <i class="fa-solid fa-house text-xs"></i>
                    <span>Back to Home</span>
                </a>

                <!-- Contact Concierge Button -->
                <a 
                    href="#" 
                    class="w-full sm:w-1/2 py-3.5 px-5 rounded-xl border border-border-light hover:border-gold bg-card-bg hover:bg-light text-dark font-semibold text-xs tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-2 group active:scale-[0.99]"
                >
                    <i class="fa-solid fa-headset text-gold group-hover:scale-110 transition-transform"></i>
                    <span>Concierge Support</span>
                </a>
            </div>

            <!-- Footer / Copyright Line -->
            <div class="mt-10 pt-6 border-t border-border-light text-center">
                <p class="text-[11px] text-dark-muted/60 uppercase tracking-widest font-medium">
                    &copy; Aurelia Luxury Private Estates & Services
                </p>
            </div>

        </div>

    </main>