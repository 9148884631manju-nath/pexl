<?php 
$frmfldvv=$_REQUEST["frmfld"];
$flo=$_REQUEST["flo"];
require_once $_REQUEST["page"].".php";
?>