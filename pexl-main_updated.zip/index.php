<?php 
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();


$theme = (isset($_REQUEST['theme'])) ? $_REQUEST['theme'] : "";
if(file_exists($theme)){ 
 require_once "inc/glob.php";
require_once $theme; 
}else{ }


$proj = (isset($_REQUEST['proj'])) ? $_REQUEST['proj'] : "web";
if($proj==""){}else{
 if(file_exists($proj."/blocks/pre-header.php")){
 include_once $proj."/blocks/pre-header.php";}else{}
  if(file_exists($proj."/blocks/content.php")){
 include_once $proj."/blocks/content.php";}else{}
if(file_exists($proj."/blocks/suf-footer.php")){
 include_once $proj."/blocks/suf-footer.php";}else{}
}
?>