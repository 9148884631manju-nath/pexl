<?php 
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();
$code = (isset($_REQUEST['code'])) ? $_REQUEST['code'] : "";

$theme = (isset($_REQUEST['theme'])) ? $_REQUEST['theme'] : "";
if(file_exists($theme)){ 
 if($code=="raw"){}else{
 require_once "inc/glob.php";
 }
 require_once $theme; 
}else{ }

$proj = (isset($_REQUEST['proj'])) ? $_REQUEST['proj'] : "";
$pr="";
if($code=="raw"){}else{
if($proj==""){$pr="111";}else{
  $projx="projects/".$proj; 
  if(file_exists($projx."/blocks/pre-header.php")){include_once $projx."/blocks/pre-header.php";}else{$pr.="1";}
  if(file_exists($projx."/blocks/content.php")){include_once $projx."/blocks/content.php";}else{$pr.="1";}
  if(file_exists($projx."/blocks/suf-footer.php")){include_once $projx."/blocks/suf-footer.php";}else{$pr.="1";}
 }
}
if($pr=="111"){require_once "inc/glob.php"; $fx="cp";require_once "createproject.php";}else{}
?>