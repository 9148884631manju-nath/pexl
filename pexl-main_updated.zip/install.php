<?php
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();
$proj=isset($_REQUEST['proj']) ? $_REQUEST['proj'] : "web";
$proj=$r->setProj($proj)."/";
$res="\n".'$filepath="'.$proj.'/data/webcon.xlsx";'."\n".'echo $r->crpre($filepath);'."\n".'echo "Welcome";'."\n";
$fda = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0">'."\n".'<?php '.$res.' ?> </head><body>';
file_put_contents($proj."/blocks/pre-header.php",$fda);
file_put_contents($proj."/blocks/suf-footer.php",'</body></html>');
?>