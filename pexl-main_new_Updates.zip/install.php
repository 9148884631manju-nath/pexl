<?php
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();
$proj=isset($_REQUEST['proj']) ? $_REQUEST['proj'] : $proj;
$projx="projects/".$proj;
$proj=$r->setProj($projx)."/";
$res="\n".'$filepath="'.$proj.'data/webcon.xlsx";'."\n".'echo $r->crpre($filepath);'."\n".' '."\n";
$fda = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0">'."\n".'<?php '.$res.' ?> </head><body>';
$cont='<?php '."\n".'$proj=isset($_REQUEST["proj"]) ? $_REQUEST["proj"] : "web";'."\n".'$projx="projects/".$proj."/";'."\n".'$page=isset($_REQUEST["page"]) ? $_REQUEST["page"] : "";'."\n".'$webset = (isset($_REQUEST["webset"])) ? $_REQUEST["webset"] : "";'."\n".'$pageCall = $projx."blocks/".$page.".php";'."\n".'$themeCall = $projx."themes/".$page.".php";'."\n".'$webSetCall = $projx."webset/".$webset.".php";'."\n".'if($webset==""){'."\n".'if($page==""){'."\n".'echo \'<div class="max-w-7xl mx-auto px-6 pt-16 pb-12 lg:pt-24 lg:pb-20"><h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight text-gold text-center"><img src="pexl-logo.png" width="200" /></h1><br/><br/><p class=" sm:text-lg leading-relaxed p-5 text-dark">PEXL is an ultra-lightweight, signal-driven web app framework designed for high-performance frontend micro-apps. Native Twind integration gives you instant dynamic styling without context setup.</p><button type="button" onclick="window.location=\\\'render.php?proj=\'.$proj.\'\\\'" class="px-4 py-2 bg-gold hover:bg-gold-hover text-dark text-xs font-bold rounded-xl shadow-sm transition-colors">Create Elements</button></div>\';'."\n".'require_once "formset/viewelements.php";'."\n".'}else{'."\n".' if(file_exists($pageCall)){'."\n".'require_once $pageCall;'."\n".'}else{'."\n".'if(file_exists($themeCall)){'."\n".'require_once $themeCall;'."\n".'}else{'."\n".'
   echo "Invalid Page";'."\n".'  }'."\n".'}'."\n".'}'."\n".'}else{'."\n".' require_once $webSetCall;'."\n".'}'."\n".'?>';
$pv="";
if(file_put_contents($proj."blocks/pre-header.php",$fda)){$pv.="1";}else{}
if(file_put_contents($proj."blocks/content.php",$cont)){$pv.="1";}else{}
if(file_put_contents($proj."blocks/suf-footer.php",'</body></html>')){$pv.="1";}else{}
if($pv=="111"){?><script>window.location.reload();</script><?php }else{}

?>