<?php
$sd = $r->sdir($projx."themes");
if(count($sd)>0){
 $html=$r->htmlint( 
 $sd, 
 [
     ["db","filename","filename","Project","","",""],
     ["db","filename","basename","Link","","?proj=".$proj."&page=",""],
     ["txt","TGT","TGT","_blank","","",""],
 ], 
 "templates/procard.html" 
 );
 ?><div class="max-w-7xl mx-auto px-6 pb-12 lg:pt-24 lg:pb-20">
<h1 class="text-3xl">Elements</h1><br/>
<?php
 echo $html;
 ?></div><?php
}
?>