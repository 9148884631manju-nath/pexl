<?php
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();
$proj=isset($_REQUEST['proj']) ? $_REQUEST['proj'] : $proj;
$projx="projects/".$proj;
$proj=$r->setProj($projx)."/";
$res="\n".'$filepath="'.$proj.'data/webcon.xlsx";'."\n".'echo $r->crpre($filepath);'."\n".' '."\n";
$fda = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0">'."\n".'<?php '.$res.' ?> </head><body>';
$cont='<?php
$proj=isset($_REQUEST["proj"]) ? $_REQUEST["proj"] : "";
$projx="projects/".$proj."/";
$admin=isset($_REQUEST["admin"]) ? $_REQUEST["admin"] : "";
$page=isset($_REQUEST["page"]) ? $_REQUEST["page"] : "main";
$ele=isset($_REQUEST["ele"]) ? $_REQUEST["ele"] : "";
$webset = (isset($_REQUEST["webset"])) ? $_REQUEST["webset"] : "";
$pageCall = $projx."blocks/".$page.".php";
$themeCall = $projx."themes/".$ele.".php";
$webSetCall = $projx."webset/".$webset.".php";
$apppage = $projx."pages/".$page.".php";

if($ele!=="" and file_exists($themeCall)){
  require_once $themeCall;
}else{
  if($admin!="yes"){
    if(file_exists($apppage)){
      require_once $apppage;
    }
    else
    {
      require_once "formset/404.php";
    }
  }
 }

if($admin=="yes")
{
  ?>
  <div class="min-h-screen bg-slate-50 font-sans text-slate-800 selection:bg-amber-500 selection:text-white">
  
   
  <div class="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-40 pointer-events-none"></div>

  <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    
     
    <header class="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 pb-6 mb-10 gap-4">
      <div>
         
        <h1 class="text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
          <?= $proj ?> <span class="bg-gradient-to-r from-amber-600 to-amber-500 bg-clip-text text-transparent">App</span>
        </h1>
        <p class="mt-1 text-sm text-slate-500">Manage and preview your application components seamlessly.</p>
      </div>

       
      <div class="flex items-center gap-3">
        <button onclick="window.open(\'render.php?proj=<?= $proj ?>\')" class="inline-flex items-center justify-center px-4 py-2.5 text-sm font-semibold text-white bg-amber-500 hover:bg-amber-600 active:bg-amber-700 rounded-xl shadow-sm shadow-amber-500/10 transition-all duration-200 group">
          <svg class="w-4 h-4 mr-2 stroke-[2.5]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Create Elements
        </button>
        
        <button onclick="window.open(\'?proj=<?= $proj ?>\')"  class="inline-flex items-center justify-center px-4 py-2.5 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 active:bg-slate-100 border border-slate-200 rounded-xl shadow-sm transition-all duration-200">
          View APP
        </button>
      </div>
    </header>

    
    <main>
       
      <h2 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">Your Custom Layouts</h2>

       
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php require_once "formset/viewelements.php"; ?>
         
        

      </div>
    </main>

  </div>
</div>
  <?php
} 
?>';
$pv="";
if(file_put_contents($proj."blocks/pre-header.php",$fda)){$pv.="1";}else{}
if(file_put_contents($proj."blocks/content.php",$cont)){$pv.="1";}else{}
if(file_put_contents($proj."blocks/suf-footer.php",'</body></html>')){$pv.="1";}else{}
if($pv=="111"){?><script>window.location.reload();</script><?php }else{}

?>