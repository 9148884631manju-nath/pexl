<?php
require_once __DIR__ . '/vendor/autoload.php';
use Phpxl\Pexl\ExcelReader;
$r = new ExcelReader();
$proj=isset($_REQUEST['proj']) ? $_REQUEST['proj'] : $proj;
$projx="projects/".$proj;
$proj=$r->setProj($projx)."/";
$res="\n".'$filepath="'.$proj.'data/webcon.xlsx";'."\n".'echo $r->crpre($filepath);'."\n".' '."\n";
$fda = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0">'."\n".'<?php '.$res.' ?> </head><body>';
$cont='<?php
$proj=isset($_REQUEST["proj"]) ? $_REQUEST["proj"] : "";
$projx="projects/".$proj."/";
$admin=isset($_REQUEST["admin"]) ? $_REQUEST["admin"] : "";
$page=isset($_REQUEST["page"]) ? $_REQUEST["page"] : "main";
$ele=isset($_REQUEST["ele"]) ? $_REQUEST["ele"] : "";
$webset = (isset($_REQUEST["webset"])) ? $_REQUEST["webset"] : "";
$pageCall = $projx."blocks/".$page.".php";
$themeCall = $projx."themes/".$ele.".php";
$webSetCall = $projx."webset/".$webset.".php";
$apppage = $projx."pages/".$page.".php";

if($ele!=="" and file_exists($themeCall)){
  require_once $themeCall;
}else{
  if($admin!="yes"){
    if(file_exists($apppage)){
      require_once $apppage;
    }
    else
    {
      require_once "formset/404.php";
    }
  }
 }

if($admin=="yes")
{
  echo \'<div class="max-w-7xl mx-auto px-6 pt-5 pb-12 lg:pt-24 lg:pb-20">
  <div>
  <h1 class="font-serif sm:text-4xl font-bold text-dark mt-2 tracking-tight">\'.$proj.\' App</h1><br/>
  </div>
  <button type="button" onclick="window.open(\\\'render.php?proj=\'.$proj.\'\\\')"class="px-4 py-2 bg-gold hover:bg-gold-hover text-dark text-xs font-bold rounded-xl shadow-sm transition-colors">Create Elements</button> <button type="button" onclick="window.open(\\\'?proj=\'.$proj.\'\\\')" class="px-4 py-2 bg-gold hover:bg-gold-hover text-dark text-xs font-bold rounded-xl shadow-sm transition-colors">View APP</button></div>\';
  ?><div class="w-full"><?php require_once "formset/viewelements.php"; ?></div><?php
} 
?>';
$pv="";
if(file_put_contents($proj."blocks/pre-header.php",$fda)){$pv.="1";}else{}
if(file_put_contents($proj."blocks/content.php",$cont)){$pv.="1";}else{}
if(file_put_contents($proj."blocks/suf-footer.php",'</body></html>')){$pv.="1";}else{}
if($pv=="111"){?><script>window.location.reload();</script><?php }else{}

?>