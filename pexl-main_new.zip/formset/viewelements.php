<?php
$sd = $r->sdir($projx."themes");
if(count($sd)>0){
 $html=$r->htmlint( 
 $sd, 
 [
     ["db","filename","filename","Project","","",""],
     ["db","filename","basename","Link","","?proj=".$proj."&ele=",""],
     ["txt","TGT","TGT","_blank","","",""],
 ], 
 "templates/procard.html" 
 );
 ?>
 <div class="flex max-w-7xl mx-auto px-6 pb-12 lg:pt-24 lg:pb-20">
<?php
 echo $html;
 ?></div><?php
}
?>